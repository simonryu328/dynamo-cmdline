# -*- coding: utf-8 -*-
"""cli.__main__: executed when dynamo directory is called as a script."""

from .cli import main
main()
